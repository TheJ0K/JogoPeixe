import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.*;
import java.awt.Font;
/**
 * Write a description of class score here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Score extends Actor
{
    private int value = 0;
    private int target = 0;
    private String text;
    private int stringLength;

    public Score()
    {
        this("");
    }

    public Score(String prefix)
    {
        text = prefix;
        stringLength = (text.length() + 2) * 16;

        setImage(new GreenfootImage(stringLength, 24));
        GreenfootImage image = getImage();
        Font font = image.getFont();
        image.setFont(font.deriveFont(24.0F));  // use larger font
        
        updateImage();
    }
    
    public void act() {
        if(value < target) {
            value++;
            updateImage();
            Greenfoot.playSound("score.wav");
        }
        else if(value > target) {
            value--;
            updateImage();
            Greenfoot.playSound("score.wav");
        }
    }

    public void add(int score)
    {
        target += score;
    }

    public void subtract(int score)
    {
        target -= score;
    }

    public int getValue()
    {
        return value;
    }

    /**
     * Make the image
     */
    private void updateImage()
    {
        GreenfootImage image = getImage();
        image.clear();
        image.setColor(Color.YELLOW);
        
        image.drawString(text + value, 1, 18);
    }
}