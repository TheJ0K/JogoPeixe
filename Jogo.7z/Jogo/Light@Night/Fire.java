import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Fire here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Fire extends Actor
{
    private int imageNumber;   
    private int count = 1; 
    /**
     * Act - do whatever the Fire wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
        changeImage();
        makeSmoke();

        
        setLocation(getX(), getY() +1);
        if (getY() == 450) 
        {
            getWorld().removeObject(this);
        }
    }

    public void changeImage()
    {
        imageNumber++;
        if (imageNumber == 3) {
            imageNumber = 0;
        }
        setImage("Fire-" + imageNumber + ".png");
    }
    
    private void makeSmoke()
    {
        count--;
        if (count == 0) 
        {
            getWorld().addObject ( new Smoke(), getX(), getY());
            count = 1;
        }
    }
}
